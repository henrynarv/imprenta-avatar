package com.avatar.TiendaVirtualAvatarImprenta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaVirtualAvatarImprentaApplicationTests {

	@Test
	void contextLoads() {
	}

}
