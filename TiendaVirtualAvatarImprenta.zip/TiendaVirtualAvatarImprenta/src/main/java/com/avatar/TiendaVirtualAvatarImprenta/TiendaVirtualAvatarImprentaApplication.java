package com.avatar.TiendaVirtualAvatarImprenta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaVirtualAvatarImprentaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaVirtualAvatarImprentaApplication.class, args);
	}

}
